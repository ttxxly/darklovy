package com.ttxxly.reader.ui.feedback;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.ttxxly.reader.R;

public class FeedbackActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
    }
}
