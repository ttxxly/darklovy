package com.ttxxly.reader.ui.feedback;

/**
 * Description:
 * date: 2018/02/08 22:04
 * Email: ttxxly@gmail.com
 *
 * @author ttxxly
 */

public class FeedbackPresenter {
}
