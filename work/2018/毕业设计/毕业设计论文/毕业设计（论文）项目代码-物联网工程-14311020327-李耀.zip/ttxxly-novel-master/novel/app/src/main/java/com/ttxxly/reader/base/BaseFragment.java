package com.ttxxly.reader.base;

import android.support.v4.app.Fragment;

/**
 * Description: Fragment 的 基类。
 * date: 2018/02/08 17:58
 * Email: ttxxly@gmail.com
 *
 * @author ttxxly
 */

public class BaseFragment extends Fragment {
}
