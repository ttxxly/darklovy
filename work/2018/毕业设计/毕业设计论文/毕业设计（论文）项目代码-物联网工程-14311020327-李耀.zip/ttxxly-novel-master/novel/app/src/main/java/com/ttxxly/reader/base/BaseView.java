package com.ttxxly.reader.base;

/**
 * Description:
 * date: 2017/11/03 14:05
 * Email: ttxxly@gmail.com
 *
 * @author ttxxly
 */
public interface BaseView {

}
