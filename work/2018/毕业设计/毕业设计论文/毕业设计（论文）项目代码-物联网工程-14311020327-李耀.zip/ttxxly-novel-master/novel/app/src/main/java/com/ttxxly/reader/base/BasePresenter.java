package com.ttxxly.reader.base;

/**
 * Description:
 * date: 2017-11-03 14:03
 * Email: ttxxly@gmail.com
 *
 * @author ttxxly
 */
public interface BasePresenter {

    void start();

    void stop();
}
