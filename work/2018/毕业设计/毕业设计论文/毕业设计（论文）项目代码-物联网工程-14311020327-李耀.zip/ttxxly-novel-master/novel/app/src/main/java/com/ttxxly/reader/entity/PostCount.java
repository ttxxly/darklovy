package com.ttxxly.reader.entity;


import com.ttxxly.reader.base.Base;

/**
 * @author yuyh.
 * @date 2016/8/4.
 */
public class PostCount extends Base {

    public String postCount;
    public String count;
}
