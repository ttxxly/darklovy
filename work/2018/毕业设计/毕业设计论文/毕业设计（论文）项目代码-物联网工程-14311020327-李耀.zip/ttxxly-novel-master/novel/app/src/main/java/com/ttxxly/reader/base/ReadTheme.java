
package com.ttxxly.reader.base;

public class ReadTheme {

    public int theme;
}