package com.ttxxly.reader.entity;


import com.ttxxly.reader.base.Base;

import java.util.List;

/**
 * @author yuyh.
 * @date 2016/8/4.
 */
public class AutoComplete extends Base {


    public List<String> keywords;
}
