package com.ttxxly.reader.ui.fragment.user;

import com.ttxxly.reader.base.BasePresenter;
import com.ttxxly.reader.base.BaseView;

/**
 * Description:
 * date: 2018/02/08 21:57
 * Email: ttxxly@gmail.com
 *
 * @author ttxxly
 */

public class UserContract  {

    interface View extends BaseView {

        /**
         * 初始化组件
         */
        void init();
    }

    interface Presenter extends BasePresenter {

    }
}
