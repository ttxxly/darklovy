package com.ttxxly.reader.base;

import java.io.Serializable;

/**
 * @author yuyh.
 * @date 2016/8/4.
 */
public class Base implements Serializable {

    public boolean ok;
}
