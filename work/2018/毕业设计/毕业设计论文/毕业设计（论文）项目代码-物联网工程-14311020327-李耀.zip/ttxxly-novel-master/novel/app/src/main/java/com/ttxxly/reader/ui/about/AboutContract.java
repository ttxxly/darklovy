package com.ttxxly.reader.ui.about;

/**
 * Description:
 * date: 2018/02/08 22:05
 * Email: ttxxly@gmail.com
 *
 * @author ttxxly
 */

public class AboutContract {
}
