<?php
/**
 * 解决 Emoji 表情无法使用的问题
 *
 * @since Unknown
 * @deprecated Beginning 4.0.1 Use Bing_emoji_url_cdnjs()
 *
 * 添加于 Beginning 4.0.2 版本，4.0.1 出于疏忽忘记将函数移动至此，而是
 * 直接被删除，这里补上。
 *
 * `add_filter( 'emoji_url', 'Bing_emoji_url_maxcdn', 8 );`
 */
function Bing_emoji_url_maxcdn() {
	_deprecated_function( __FUNCTION__, '4.0.1', 'Bing_emoji_url_cdnjs()' );
	return set_url_scheme( '//twemoji.maxcdn.com/72x72/' );
}

/**
 * 解决 SVG Emoji 表情无法使用的问题
 *
 * @since Unknown
 * @deprecated Beginning 4.0.1 Use Bing_emoji_svg_url_cdnjs()
 *
 * 添加于 Beginning 4.0.2 版本，4.0.1 出于疏忽忘记将函数移动至此，而是
 * 直接被删除，这里补上。
 *
 * `add_filter( 'emoji_svg_url', 'Bing_emoji_svg_url_maxcdn', 8 );`
 */
function Bing_emoji_svg_url_maxcdn() {
	_deprecated_function( __FUNCTION__, '4.0.1', 'Bing_emoji_svg_url_cdnjs()' );
	return set_url_scheme( '//twemoji.maxcdn.com/svg/' );
}

/**
 * 删除 MaxCDN 消失的表情
 *
 * 因为 MaxCDN 莫名其妙的删除了两个表情，导致出现图片 404 的情况，所以暂时删除了这两个表情。
 *
 * @since Unknown
 * @deprecated Beginning 4.0.1
 *
 * add_action( 'init', 'Bing_remove_die_smileys', 8 );
 */
function Bing_remove_die_smileys() {
	global $wpsmiliestrans;
	_deprecated_function( __FUNCTION__, '4.0.1' );

	if( !isset( $wpsmiliestrans ) || !is_array( $wpsmiliestrans ) )
		return;

	$remove_smileys = array(
		"\xf0\x9f\x99\x82",
		"\xf0\x9f\x99\x81",

		"\xf0\x9f\x99\x84"
	);

	foreach ( $wpsmiliestrans as $key => $smiley )
		if ( in_array( $smiley, $remove_smileys ) )
			unset( $wpsmiliestrans[$key] );
}

/**
 * 保存主题版本
 *
 * @since Unknown
 * @deprecated Beginning 4.0.2 Use Bing_check_db_version()
 *
 * `add_action( 'init', 'Bing_save_theme_version', 16 );`
 */
function Bing_save_theme_version() {
	_deprecated_function( __FUNCTION__, '4.0.2', 'Bing_check_db_version' );
	return Bing_check_db_version();
}

// End of page.
