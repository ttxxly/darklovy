<?php
/**
 * 文章访问计数
 *
 * @since Unknown
 * @since 4.0.1 统计所有公开文章类型和文章状态的文章。
 */
function Bing_post_statistics_views() {
	if ( !is_singular() )
		return;

	if ( !$post_status = get_post_status_object( get_post_status() ) )
		return;

	if ( !$post_status->public )
		return;

	if ( !$post_type = get_post_type_object( get_post_type() ) )
		return;

	if ( !$post_type->public )
		return;

	$views = (int) get_post_meta( get_the_ID(), 'views', true );
	update_post_meta( get_the_ID(), 'views', $views + 1 );
}
add_action( 'template_redirect', 'Bing_post_statistics_views' );

/**
 * 获取计数
 */
function Bing_post_views( $post = null ){
	$post = get_post( $post );
	$views = (int) get_post_meta( $post->ID, 'views', true );
	return apply_filters( 'post_views', number_format_i18n( $views ), $post, $views );
}

//End of page.
