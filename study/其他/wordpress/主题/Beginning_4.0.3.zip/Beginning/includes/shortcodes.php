<?php
/**
 * 文章存档简码
 */
function Bing_shortcode_archives() {
	$query = new WP_Query( 	array(
		'nopaging'            => true,
		'ignore_sticky_posts' => true,
		'post_type'           => 'post'
	) );

	if ( !$query->have_posts() )
		return __( '没有文章。' );

	$month   = null;
	$heading = Bing_get_main_list_title_tag();
	$code    = '';

	while ( $query->have_posts() ) {
		$query->the_post();

		if ( ( $current_month = get_the_date( 'Y-m' ) ) != $month ) {
			if ( $month )
				$code .= '</ul>';

			$month = $current_month;
			$code .= "<$heading>$month</$heading><ul>";
		}

		$url_attr = esc_url( get_permalink() );
		$day      = get_the_date( 'd' );
		$title    = get_the_title();

		$code .= "<li>$day - <a href='$url_attr'>$title</a></li>";
	}

	$code .= '</ul>';

	wp_reset_postdata();
	return $code;
}
add_shortcode( 'archives', 'Bing_shortcode_archives' );

/**
 * 标签云简码
 */
function Bing_shortcode_tags() {
	return wp_tag_cloud( 'echo=0&number=0' );
}
add_shortcode( 'tags', 'Bing_shortcode_tags' );

// End of page.
